package com.example.eventservice.controller;

import com.example.eventservice.model.RSVP;
import com.example.eventservice.service.RSVPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rsvp")
public class RSVPController {

    @Autowired
    private RSVPService rsvpService;

    @PostMapping
    public RSVP respond(@RequestBody RSVP rsvp) {
        return rsvpService.respond(rsvp);
    }

    @GetMapping("/event/{eventId}")
    public List<RSVP> getByEvent(@PathVariable Long eventId) {
        return rsvpService.getByEvent(eventId);
    }
}