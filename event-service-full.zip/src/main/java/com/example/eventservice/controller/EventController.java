package com.example.eventservice.controller;

import com.example.eventservice.model.Event;
import com.example.eventservice.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/events")
public class EventController {

    @Autowired
    private EventService eventService;

    @PostMapping
    public Event create(@RequestBody Event event) {
        return eventService.create(event);
    }

    @GetMapping("/community/{communityId}")
    public List<Event> getByCommunity(@PathVariable Long communityId) {
        return eventService.getEvents(communityId);
    }
}