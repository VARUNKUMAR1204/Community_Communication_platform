package com.example.eventservice.service;

import com.example.eventservice.model.RSVP;

import java.util.List;

public interface RSVPService {
    RSVP respond(RSVP rsvp);
    List<RSVP> getByEvent(Long eventId);
}