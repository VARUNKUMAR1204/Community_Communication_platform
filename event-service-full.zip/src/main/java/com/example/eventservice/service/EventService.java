package com.example.eventservice.service;

import com.example.eventservice.model.Event;
import java.util.List;

public interface EventService {
    Event create(Event event);
    List<Event> getEvents(Long communityId);
}