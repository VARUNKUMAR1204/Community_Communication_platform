package com.example.eventservice.service.impl;

import com.example.eventservice.model.RSVP;
import com.example.eventservice.repository.RSVPRepository;
import com.example.eventservice.service.RSVPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RSVPServiceImpl implements RSVPService {
    @Autowired
    private RSVPRepository rsvpRepository;

    @Override
    public RSVP respond(RSVP rsvp) {
        RSVP existing = rsvpRepository.findByEventIdAndUserId(rsvp.getEventId(), rsvp.getUserId());
        if (existing != null) {
            existing.setAttending(rsvp.isAttending());
            return rsvpRepository.save(existing);
        }
        return rsvpRepository.save(rsvp);
    }

    @Override
    public List<RSVP> getByEvent(Long eventId) {
        return rsvpRepository.findByEventId(eventId);
    }
}