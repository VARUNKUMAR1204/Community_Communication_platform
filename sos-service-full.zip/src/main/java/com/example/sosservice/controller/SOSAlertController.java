package com.example.sosservice.controller;

import com.example.sosservice.model.SOSAlert;
import com.example.sosservice.service.SOSAlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sos")
public class SOSAlertController {

    @Autowired
    private SOSAlertService sosAlertService;

    @PostMapping("/send")
    public SOSAlert sendSOS(@RequestBody SOSAlert alert) {
        return sosAlertService.sendSOS(alert);
    }

    @GetMapping("/view/pending")
    public List<SOSAlert> viewPending() {
        return sosAlertService.getPendingAlerts();
    }

    @GetMapping("/history/{userId}")
    public List<SOSAlert> viewHistory(@PathVariable Long userId) {
        return sosAlertService.getHistoryByUser(userId);
    }

    @PostMapping("/acknowledge/{id}")
    public SOSAlert acknowledge(@PathVariable Long id) {
        return sosAlertService.acknowledgeSOS(id);
    }
}