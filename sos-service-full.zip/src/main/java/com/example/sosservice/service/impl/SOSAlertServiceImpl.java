package com.example.sosservice.service.impl;

import com.example.sosservice.model.SOSAlert;
import com.example.sosservice.repository.SOSAlertRepository;
import com.example.sosservice.service.SOSAlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SOSAlertServiceImpl implements SOSAlertService {

    @Autowired
    private SOSAlertRepository repository;

    @Override
    public SOSAlert sendSOS(SOSAlert alert) {
        return repository.save(alert);
    }

    @Override
    public List<SOSAlert> getPendingAlerts() {
        return repository.findByStatus("PENDING");
    }

    @Override
    public List<SOSAlert> getHistoryByUser(Long userId) {
        return repository.findByUserId(userId);
    }

    @Override
    public SOSAlert acknowledgeSOS(Long id) {
        SOSAlert alert = repository.findById(id).orElse(null);
        if (alert != null) {
            alert.setStatus("ACKNOWLEDGED");
            repository.save(alert);
        }
        return alert;
    }
}