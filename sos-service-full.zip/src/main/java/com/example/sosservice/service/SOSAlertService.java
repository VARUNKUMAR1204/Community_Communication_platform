package com.example.sosservice.service;

import com.example.sosservice.model.SOSAlert;
import java.util.List;

public interface SOSAlertService {
    SOSAlert sendSOS(SOSAlert alert);
    List<SOSAlert> getPendingAlerts();
    List<SOSAlert> getHistoryByUser(Long userId);
    SOSAlert acknowledgeSOS(Long id);
}