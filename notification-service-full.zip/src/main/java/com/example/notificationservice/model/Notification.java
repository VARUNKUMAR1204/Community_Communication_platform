package com.example.notificationservice.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String message;
    private String priority;
    private LocalDateTime sentAt;
    private boolean fallbackSent;
    private Long userId;

    public Notification() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public LocalDateTime getSentAt() { return sentAt; }
    public void setSentAt(LocalDateTime sentAt) { this.sentAt = sentAt; }
    public boolean isFallbackSent() { return fallbackSent; }
    public void setFallbackSent(boolean fallbackSent) { this.fallbackSent = fallbackSent; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
}