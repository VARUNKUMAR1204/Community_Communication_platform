package com.example.notificationservice.service.impl;

import com.example.notificationservice.model.Notification;
import com.example.notificationservice.repository.NotificationRepository;
import com.example.notificationservice.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Override
    public Notification send(Notification notification) {
        notification.setSentAt(LocalDateTime.now());
        notification.setFallbackSent(false);
        return notificationRepository.save(notification);
    }

    @Override
    public List<Notification> getUnread(Long userId) {
        return notificationRepository.findByUserIdAndFallbackSentFalse(userId);
    }

    @Override
    public Notification markAsSeen(Long id) {
        Notification n = notificationRepository.findById(id).orElse(null);
        if (n != null) {
            n.setFallbackSent(true);
            return notificationRepository.save(n);
        }
        return null;
    }

    @Scheduled(fixedDelay = 30000)
    public void fallbackDeliveryCheck() {
        List<Notification> notifications = notificationRepository.findAll();
        for (Notification n : notifications) {
            if (!n.isFallbackSent() && n.getSentAt().isBefore(LocalDateTime.now().minusSeconds(30))) {
                n.setFallbackSent(true);
                notificationRepository.save(n);
            }
        }
    }
}