package com.example.notificationservice.service;

import com.example.notificationservice.model.Notification;

import java.util.List;

public interface NotificationService {
    Notification send(Notification notification);
    List<Notification> getUnread(Long userId);
    Notification markAsSeen(Long id);
}