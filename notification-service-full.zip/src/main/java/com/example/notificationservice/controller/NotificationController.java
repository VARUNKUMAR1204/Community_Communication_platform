package com.example.notificationservice.controller;

import com.example.notificationservice.model.Notification;
import com.example.notificationservice.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @PostMapping("/send")
    public Notification send(@RequestBody Notification notification) {
        return notificationService.send(notification);
    }

    @GetMapping("/unread/{userId}")
    public List<Notification> getUnread(@PathVariable Long userId) {
        return notificationService.getUnread(userId);
    }

    @PostMapping("/mark-seen/{id}")
    public Notification markSeen(@PathVariable Long id) {
        return notificationService.markAsSeen(id);
    }
}