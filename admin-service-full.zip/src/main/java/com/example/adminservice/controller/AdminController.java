package com.example.adminservice.controller;

import com.example.adminservice.model.Admin;
import com.example.adminservice.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admins")
public class AdminController {
    @Autowired
    private AdminService adminService;

    @GetMapping("/{id}")
    public Admin getAdminById(@PathVariable Long id) {
        return adminService.getAdminById(id);
    }

    @GetMapping("/community/{communityId}")
    public List<Admin> getAdminsByCommunity(@PathVariable Long communityId) {
        return adminService.getAdminsByCommunity(communityId);
    }
}