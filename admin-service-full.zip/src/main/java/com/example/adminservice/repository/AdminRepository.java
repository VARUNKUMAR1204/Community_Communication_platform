package com.example.adminservice.repository;

import com.example.adminservice.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AdminRepository extends JpaRepository<Admin, Long> {
    List<Admin> findByCommunityId(Long communityId);
}