package com.example.adminservice.service.impl;

import com.example.adminservice.model.Admin;
import com.example.adminservice.repository.AdminRepository;
import com.example.adminservice.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminRepository adminRepository;

    @Override
    public Admin getAdminById(Long id) {
        return adminRepository.findById(id).orElse(null);
    }

    @Override
    public List<Admin> getAdminsByCommunity(Long communityId) {
        return adminRepository.findByCommunityId(communityId);
    }
}