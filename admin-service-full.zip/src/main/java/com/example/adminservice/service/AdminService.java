package com.example.adminservice.service;

import com.example.adminservice.model.Admin;
import java.util.List;

public interface AdminService {
    Admin getAdminById(Long id);
    List<Admin> getAdminsByCommunity(Long communityId);
}